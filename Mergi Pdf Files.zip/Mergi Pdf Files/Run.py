from PyPDF2 import PdfFileMerger, PdfFileReader
merger = PdfFileMerger()

merger.append(PdfFileReader(open("1.pdf", 'rb')))
merger.append(PdfFileReader(open("2.pdf", 'rb')))

merger.write("merged.pdf")